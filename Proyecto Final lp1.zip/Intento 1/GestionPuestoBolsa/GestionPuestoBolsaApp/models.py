from django.db import models

# Create your models here.


class Moneda(models.Model):
    idMoneda = models.IntegerField(primary_key=True)
    nombreMoneda = models.CharField(max_length=50, null=False)
    precioActual = models.DecimalField(max_digits=5, decimal_places=2)
    precioAnterior = models.DecimalField(max_digits=5, decimal_places=2)

    def __str__(self):
        return self.nombreMoneda

class Acciones(models.Model):
    idAcciones = models.IntegerField(primary_key=True)
    nombre = models.CharField(max_length=50, null=False)
    descripcion = models.CharField(max_length=50, null=False)
    empresa = models.CharField(max_length=50, null=False)
    monedaAccion = models.CharField(max_length=50)
    valorAccion = models.DecimalField(max_digits=5, decimal_places=2)
    vigencia = models.DateField()

    def __str__(self):
        return self.nombre

class estadisticas(models.Model):
    titulo = models.CharField(max_length=50)
    imagen = models.ImageField()

    def __str__(self):
        return self.titulo