from django.apps import AppConfig


class GestionpuestobolsaappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'GestionPuestoBolsaApp'
