from django.urls import path, include
from . import views

urlpatterns = [
    path('registro', views.registro, name='registro'),
    path('', views.inicio, name='inicio'),
    path('index', views.index, name='index'),
    path('mostrarAcciones', views.mostrarAcciones, name='mostrarAcciones'),
    path('agregarAcciones', views.agregarAcciones, name='agregarAcciones'),
    path('removerAccion', views.removerAccion, name='removerAccion'),
    path('removerAccion/<int:idAccion>', views.removerAccion, name='removerAccion'),
    path('estadisticas', views.estadisticas, name='estadisticas'),
    path('mostrarEstadisticas', views.mostrarEstadisticas, name='mostrarEstadisticas'),
    path('salir/', views.salir, name='salir'),
]
