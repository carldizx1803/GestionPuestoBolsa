from django.contrib import admin
from .models import Acciones, Moneda, estadisticas

# Register your models here.

admin.site.register(Acciones)
admin.site.register(Moneda)
admin.site.register(estadisticas)
