from email import message
from multiprocessing import context
from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout, authenticate, login
from .forms import CustomerUserCreationForm
from django.contrib import messages

# Create your views here.

from unicodedata import decimal
from django.shortcuts import render, HttpResponse

from .models import Moneda, Acciones, estadisticas
from datetime import datetime
from django.db.models import Q

# Create your views here.

def registro(request):
    data = {
        'form': CustomerUserCreationForm()
    }

    if request.method == 'POST':
        formulario = CustomerUserCreationForm(data = request.POST)
        if formulario.is_valid():
            formulario.save()
            user = authenticate(username=formulario.cleaned_data["username"], password=formulario.cleaned_data["password1"])
            login(request,user)
            messages.success(request, "El registro ha sido exitoso")
            return redirect(to="registration/login")
            data["form"] = formulario

    return render(request,'registration/registro.html',data)

def inicio(request):
    return render(request, 'inicio.html')


def salir(request):
    logout(request)
    return redirect('/')

def estadisticas(request):
    return render(request, 'estadisticas.html')

def index(request):
    return render(request, 'index.html')


def mostrarAcciones(request):
    acciones = Acciones.objects.all()
    context = {
        'acciones': acciones
    }
    print(context)
    return render(request, 'mostrarAcciones.html', context)


def agregarAcciones(request):
    if request.method == 'POST':
        nombre = request.POST['nombre']
        descripcion = request.POST['descripcion']
        empresa = (request.POST['empresa'])
        monedaAccion = (request.POST['monedaAccion'])
        valorAccion = float(request.POST['valorAccion'])
        nueva_accion = Acciones(nombre= nombre, descripcion=descripcion, empresa=empresa, monedaAccion=monedaAccion, valorAccion=valorAccion, vigencia = datetime.now())
        nueva_accion.save()
        return HttpResponse('Accion agregada')
    elif request.method=='GET':
        return render(request, 'agregarAcciones.html')
    else:
        return HttpResponse("Ocurrio un problema, la accion no fue agregada")

def removerAccion(request, idAcciones = 0):
    if idAcciones:
        try:
            accionRemovida = Acciones.objects.get(id=idAcciones)
            accionRemovida.delete()
            return HttpResponse("La accion ha sido removida")
        except:
            return HttpResponse("Por favor, introduzca un identificador valido")
    accion = Acciones.objects.all()
    context = {
        'accion': accion
    }
    return render(request, 'removerAccion.html',context)

def agregarGrafico(request):
    if request.method == 'POST':
        titulo = request.POST['titulo']
        imagen = request.POST['imagen']
        nueva_estadistica = estadisticas(titulo=titulo, imagen=imagen)
        nueva_estadistica.save()
        return HttpResponse('Grafico agregado')
    elif request.method=='GET':
        return render(request, 'agregarAcciones.html')
    else:
        return HttpResponse("Ocurrio un problema, la accion no fue agregada")

def mostrarEstadisticas(request):
    return render(request, 'mostrarEstadisticas.html')
